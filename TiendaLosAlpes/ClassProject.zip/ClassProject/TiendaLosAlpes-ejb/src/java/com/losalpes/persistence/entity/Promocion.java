package com.losalpes.persistence.entity;

import javax.faces.model.SelectItem;

/**
 * POJO de Promociones
 * @author Kerlyn Hans
 */
public class Promocion {
    private String nombre;

    private Mueble mueble;

    private String furniture;

    private String furnitype;

    private String fechaInicio;

    private String fechaFin;

    public void Promocion(){
    }
    
    //public void Promocion(String nombre, Mueble mueble, String fechaInicio, String fechaFin){
    public void Promocion(String nombre, String furniture, String furnitype, String fechaInicio, String fechaFin){
        this.nombre = nombre;
        this.furniture = furniture;
        this.furnitype = furnitype;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public String getFurnitype() {
        return furnitype;
    }

    public void setFurnitype(String furnitype) {
        this.furnitype = furnitype;
    }

    public String getFurniture() {
        return furniture;
    }

    public void setFurniture(String furniture) {
        this.furniture = furniture;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Mueble getMueble() {
        return mueble;
    }

    public void setMueble(Mueble mueble) {
        this.mueble = mueble;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
