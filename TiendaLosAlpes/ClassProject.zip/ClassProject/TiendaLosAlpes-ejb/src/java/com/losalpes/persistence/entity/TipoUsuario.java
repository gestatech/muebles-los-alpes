package com.losalpes.persistence.entity;

/**
 * Enum de Tipos de Usuario.  Roles
 * @author Memo Toro
 */
public enum TipoUsuario {
    ADMINISTRADOR, CLIENTE
}