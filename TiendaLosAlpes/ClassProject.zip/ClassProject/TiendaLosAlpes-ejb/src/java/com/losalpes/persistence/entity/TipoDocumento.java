package com.losalpes.persistence.entity;

/**
 * Enum de Tipo de Documentos
 * @author Memo Toro
 */
public enum TipoDocumento {
    CEDULA,PASAPORTE,NIT
}