/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.losalpes.catalog;

import com.losalpes.persistence.entity.Promocion;
import com.losalpes.persistencia.IPromociones;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateful;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

/**
 *
 * @author Kerlyn Hans
 */
@Stateful
public class PromocionServices implements IPromocionServices {

    @EJB
    private IPromociones persistencePromos;

    @Resource(mappedName="jms/NuevaPromocionTopicFactory")
    private ConnectionFactory connectionFactory;

    @Resource(mappedName="jms/NuevaPromocionTopic")
    private Topic topico;

    /**
     * Contiene la información del vendedor actual
     */
    private Promocion cPromocion;

    public PromocionServices() {
    }

    public Promocion newPromocion() {
        cPromocion = new Promocion();
        return(cPromocion);
    }

    private Message crearMensajePromocion(Session session) throws JMSException{
        String msg = cPromocion.getNombre() + "|";
        msg += cPromocion.getFurniture() + "|";
        msg += cPromocion.getFurnitype() + "|";
        msg += cPromocion.getFechaInicio() + "|";
        msg += cPromocion.getFechaFin();

        TextMessage tm = session.createTextMessage();
        tm.setText(msg);
        return(tm);
    }

    private void notificarMensajePromocion() throws JMSException{
        Connection conexion = connectionFactory.createConnection();
        Session session = conexion.createSession(false, Session.AUTO_ACKNOWLEDGE);
        MessageProducer messageProducer = session.createProducer((Destination) topico);

        try {
            messageProducer.send(crearMensajePromocion(session));
        } catch (JMSException e) {
            Logger.getLogger(PromocionServices.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            if(session != null){
                try {
                    session.close();
                } catch (JMSException ex) {
                    Logger.getLogger(this.getClass().getName()).log(Level.WARNING, "Error cerrando la session", ex);
                }
                if(conexion != null){
                    conexion.close();
                }
            }
        }
    }

    public void create() {
        persistencePromos.registrarPromocion(cPromocion);

        try{
            notificarMensajePromocion();
        }catch(JMSException ex){
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "Error enviando la notificación de la nueva promoción.", ex);
        }
    }

    public List <Promocion> findAll() {
        return persistencePromos.retornarPromociones();
    }

    public Promocion getPromocion() {
        return (cPromocion);
    }

    public void setPromocion(Promocion promo) {
        cPromocion = promo;
    }
}
