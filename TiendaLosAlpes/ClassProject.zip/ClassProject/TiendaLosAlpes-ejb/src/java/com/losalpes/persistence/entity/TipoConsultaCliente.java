package com.losalpes.persistence.entity;

/**
 * Enum de Tipo de Criterio de COnsulta a Cliente.
 * @author Memo Toro
 */
public enum TipoConsultaCliente {
    NUMERO_DOCUMENTO,NOMBRES,EMAIL
}