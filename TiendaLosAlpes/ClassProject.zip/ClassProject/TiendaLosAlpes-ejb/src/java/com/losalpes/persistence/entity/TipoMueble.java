package com.losalpes.persistence.entity;

/**
 * Enum de Tipos de Muebles
 * @author Memo Toro
 */
public enum TipoMueble {
    INTERIOR,EXTERIOR
}