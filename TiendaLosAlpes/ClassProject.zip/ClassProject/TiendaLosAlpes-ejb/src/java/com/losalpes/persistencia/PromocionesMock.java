package com.losalpes.persistencia;

import com.losalpes.persistence.entity.Promocion;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateful;

/**
 *
 * @author Kerlyn Hans
 */
@Stateful
public class PromocionesMock implements IPromociones {

    private List<Promocion> promos = new ArrayList<Promocion>();

    public void registrarPromocion(Promocion promo) {
        promos.add(promo);
    }

    public List<Promocion> retornarPromociones() {
        return promos;
    }
}
