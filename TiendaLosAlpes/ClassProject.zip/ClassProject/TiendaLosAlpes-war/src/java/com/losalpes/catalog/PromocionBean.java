package com.losalpes.catalog;

import com.losalpes.persistence.entity.Promocion;
import com.losalpes.persistence.entity.TipoMueble;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

/**
 *
 * @author Kerlyn Hans
 */
public class PromocionBean {

    @EJB
    private IPromocionServices promocionServices;

    /* Crear cache de los objetos para alimentan la interfaz para evitar el llamado excesivo
    la especificación de JSF no especifica que cada metodo se llame una unica vez
     */
    private List<Promocion> promociones;
    private Promocion promocion;

    /** Creates a new instance of PromocionBean */
    public PromocionBean() {
        
    }

    @PostConstruct
    public void init() {
        promociones = promocionServices.findAll();
        promocion = new Promocion();
//        promocion = promocionServices.getPromocion();
    }

    public String create() {
        promocionServices.setPromocion(promocion);
        promocionServices.create();
        //destroyBean();
        return "registroPromos";
    }

    public void destroyBean() {
        //FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove("PromocionBean");
    }

    public Promocion getPromocion(){
        return(promocion);
    }

    public void setPromocion(Promocion promocion) {
        this.promocion = promocion;
    }

    public List getAllPromotions(){
        return promociones;
    }
    
    public String getLimpiar(){
        promocion = promocionServices.newPromocion();
        return "admin";
    }

    public SelectItem[] getTipoMuebles(){
        TipoMueble[] tipos = TipoMueble.values();
        SelectItem[] sItems = new SelectItem[tipos.length];
        for (int i = 0; i < sItems.length; i++) {
             sItems[i] = new SelectItem(tipos[i]);
        }
        return sItems;
    }
}
