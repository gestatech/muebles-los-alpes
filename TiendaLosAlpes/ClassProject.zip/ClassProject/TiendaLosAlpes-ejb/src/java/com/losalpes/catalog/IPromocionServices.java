/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.losalpes.catalog;

import com.losalpes.persistence.entity.Promocion;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Kerlyn Hans
 */
@Local
public interface IPromocionServices {

    public List<Promocion> findAll();

    public Promocion newPromocion();

    public void create();

    public Promocion getPromocion();

    public void setPromocion(Promocion promo);
}
