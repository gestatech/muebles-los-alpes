/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.losalpes.persistencia;

import com.losalpes.persistence.entity.Promocion;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Kerlyn Hans
 */
@Local
public interface IPromociones {
    /**
     *
     * @param promo
     */
    void registrarPromocion(Promocion promo);

    List <Promocion> retornarPromociones();
}
