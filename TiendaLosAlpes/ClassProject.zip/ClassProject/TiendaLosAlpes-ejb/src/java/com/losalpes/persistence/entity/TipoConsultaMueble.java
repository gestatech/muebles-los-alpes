package com.losalpes.persistence.entity;

/**
 * Enum de Tipo Criterio de Consulta a Muebles
 * @author Memo Toro
 */
public enum TipoConsultaMueble {
    REFERENCIA,NOMBRE,TIPO
}