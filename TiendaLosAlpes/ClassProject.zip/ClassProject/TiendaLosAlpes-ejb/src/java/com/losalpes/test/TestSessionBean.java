package com.losalpes.test;

import javax.ejb.Stateless;

/**
 *
 * @author Orlando
 */
@Stateless
public class TestSessionBean implements TestSessionLocal {

    public void testMethod(String parameter, String parameter1) {
    }    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method" or "Web Service > Add Operation") 
}