/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.losalpes.jms;

import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 *
 * @author Kerlyn Hans
 */
@MessageDriven(mappedName = "jms/NuevaPromocionTopic", activationConfig =  {
        @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"),
        @ActivationConfigProperty(propertyName = "subscriptionDurability", propertyValue = "Durable"),
        @ActivationConfigProperty(propertyName = "clientId", propertyValue = "MercadeoMessageBean"),
        @ActivationConfigProperty(propertyName = "subscriptionName", propertyValue = "MercadeoMessageBean")
    })
public class MercadeoMessageBean implements MessageListener {

    @Resource
    private MessageDrivenContext mdc;
    
    public MercadeoMessageBean() {
    }

    public void onMessage(Message message) {
        TextMessage msg = null;

        try {
            if(message instanceof TextMessage){
                msg = (TextMessage)message;
                StringTokenizer tokens = new StringTokenizer(msg.getText(), "|");
                String[] datos=new String[tokens.countTokens()];
                int i=0;
                while(tokens.hasMoreTokens()){
                    datos[i]=tokens.nextToken();
                    i++;
                }

                String sMsg = "Mercadeo - Promoción " + datos[0] + " para " + datos[1] + " de " + datos[2];

                Logger.getLogger(VentasMessageBean.class.getName()).log(Level.INFO, sMsg);
            }
        }catch (JMSException ej) {
            ej.printStackTrace();
            mdc.setRollbackOnly();
        }catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
